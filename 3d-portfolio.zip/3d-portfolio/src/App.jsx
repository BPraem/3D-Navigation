import React, { useState, useEffect } from 'react';
import Verge3DViewer from './components/Verge3DViewer';
import Component1 from './components/Component1';
import Component2 from './components/Component2';
import Component3 from './components/Component3';
import Component4 from './components/Component4';
import Component5 from './components/Component5';
import Component6 from './components/Component6';
import Component7 from './components/Component7';
import Component8 from './components/Component8';

function App() {
  const [activeComponentKey, setActiveComponentKey] = useState('Button_1');

  const handleClick = (buttonName) => {
    console.log("handleClick called with:", buttonName); // <-- Debug log
    setActiveComponentKey(buttonName);
  };
  

  // Expose the handler globally so Verge3D can call it
  useEffect(() => {
    window.handleClick = handleClick;
  }, []);

  // Map Verge3D button names to actual components
  const componentMap = {
    Button_1: Component1,
    Button_2: Component2,
    Button_3: Component3,
    Button_4: Component4,
    Button_5: Component5,
    Button_6: Component6,
    Button_7: Component7,
    Button_8: Component8,
  };

  const ActiveComponent = componentMap[activeComponentKey];
  console.log("ActiveComponent is", ActiveComponent); // <-- Add this
  
  return (
    <div>
      <h1>My React + Verge3D App</h1>
      <Verge3DViewer/>
      {ActiveComponent ? <ActiveComponent /> : <div>No component selected</div>}
    </div>
  );
}

export default App;
