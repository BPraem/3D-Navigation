function About() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>About Us</h1>
      <p>We are passionate developers creating modern web apps with React.</p>
    </div>
  );
}

export default About;
