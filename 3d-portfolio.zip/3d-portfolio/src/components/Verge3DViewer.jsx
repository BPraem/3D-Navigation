import { useEffect } from "react";

function Verge3DViewer() {
  useEffect(() => {
    const v3dScript = document.createElement("script");
    v3dScript.src = "/Octahedron_3D_Navigation/v3d.js";
    v3dScript.async = true;

    v3dScript.onload = () => {
      const appScript = document.createElement("script");
      appScript.src = "/Octahedron_3D_Navigation/Octahedron_3D_Navigation.js";
      appScript.async = true;
      document.body.appendChild(appScript);

      cleanup.appScript = appScript;
    };

    document.body.appendChild(v3dScript);

    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = "/Octahedron_3D_Navigation.css";
    document.head.appendChild(link);

    const cleanup = { v3dScript, link, appScript: null };

    return () => {
      if (cleanup.v3dScript) document.body.removeChild(cleanup.v3dScript);
      if (cleanup.appScript) document.body.removeChild(cleanup.appScript);
      if (cleanup.link) document.head.removeChild(cleanup.link);
    };
  }, []);

  return (
    <div 
    style={{
      width: '100%',
      height: '600px',
      left: '500px',
      position: 'relative',
      background: 'black',
      zIndex: 10,
      overflow: 'hidden',
    }}
    id="v3d-container">
      
      <div
        id="fullscreen-button"
        className="fullscreen-button fullscreen-open"
        title="Toggle fullscreen mode"
      ></div>
    </div>
  );
}

export default Verge3DViewer;
