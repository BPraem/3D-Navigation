function Home() {
  const styles = {
    container: { padding: '2rem', textAlign: 'center' },
    title: { fontSize: '2rem', color: '#333' },
    text: { marginTop: '1rem', color: '#666' }
  };
  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Welcome to the Homepage</h1>
      <p style={styles.text}>This is the main landing page of your site.</p>
    </div>
  );
}

export default Home;
