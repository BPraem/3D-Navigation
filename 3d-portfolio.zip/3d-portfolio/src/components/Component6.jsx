function Portfolio() {
  const itemStyle = {
    width: '200px',
    height: '150px',
    backgroundColor: '#eee',
    display: 'inline-block',
    margin: '1rem',
    textAlign: 'center',
    lineHeight: '150px'
  };
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Portfolio</h1>
      <div>
        <div style={itemStyle}>Project A</div>
        <div style={itemStyle}>Project B</div>
        <div style={itemStyle}>Project C</div>
      </div>
    </div>
  );
}

export default Portfolio;
