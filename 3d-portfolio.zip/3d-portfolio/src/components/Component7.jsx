function FAQ() {
  const qaStyle = {
    margin: '1rem 0',
    padding: '1rem',
    background: '#f0f0f0',
    borderRadius: '6px'
  };
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Frequently Asked Questions</h1>
      <div style={qaStyle}>
        <strong>Q:</strong> What is React?<br />
        <strong>A:</strong> A JS library for building UIs.
      </div>
      <div style={qaStyle}>
        <strong>Q:</strong> What is Vite?<br />
        <strong>A:</strong> A fast build tool for modern frontends.
      </div>
    </div>
  );
}

export default FAQ;
