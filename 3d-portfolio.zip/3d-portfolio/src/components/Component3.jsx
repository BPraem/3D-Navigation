function Services() {
  const serviceStyle = {
    border: '1px solid #ccc',
    padding: '1rem',
    margin: '1rem 0',
    borderRadius: '8px',
    background: '#f9f9f9'
  };
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Our Services</h1>
      <div style={serviceStyle}>Web Development</div>
      <div style={serviceStyle}>UI/UX Design</div>
      <div style={serviceStyle}>Consulting</div>
    </div>
  );
}

export default Services;
