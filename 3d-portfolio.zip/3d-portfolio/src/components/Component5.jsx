function Blog() {
  const postStyle = {
    padding: '1rem',
    borderBottom: '1px solid #ddd'
  };
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Blog</h1>
      <div style={postStyle}><strong>Post 1:</strong> Intro to React</div>
      <div style={postStyle}><strong>Post 2:</strong> Styling in JS</div>
      <div style={postStyle}><strong>Post 3:</strong> Vite vs Webpack</div>
    </div>
  );
}

export default Blog;
