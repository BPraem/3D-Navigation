function Contact() {
  const formStyle = {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    maxWidth: '400px',
    margin: '2rem auto'
  };
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Contact Us</h1>
      <form style={formStyle}>
        <input type="text" placeholder="Your Name" style={{ padding: '0.5rem' }} />
        <input type="email" placeholder="Your Email" style={{ padding: '0.5rem' }} />
        <textarea placeholder="Message" style={{ padding: '0.5rem' }} />
        <button type="submit" style={{ padding: '0.5rem', backgroundColor: '#333', color: '#fff' }}>
          Send
        </button>
      </form>
    </div>
  );
}

export default Contact;
